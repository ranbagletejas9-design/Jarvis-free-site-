# JARVIS Free Browser Demo

No Claude API, API key, Python server, or paid hosting is needed.

## Publish using GitHub Pages on iPhone
1. Add `index.html` to the root of your existing GitHub repository.
2. Open repository Settings → Pages.
3. Under Build and deployment, choose Deploy from a branch.
4. Select branch `main` and folder `/ (root)`, then Save.
5. Open the website URL shown in the Pages section after publishing.

This demo provides a futuristic interface, simple built-in responses, browser text-to-speech, and optional speech recognition when supported. It is not a full AI model and does not connect to Claude. Never put API keys in this static website.
